package gestor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import model.Cliente;
import model.Especie;
import model.Mascota;

public class GestorBD 
{
    private String CONN = "jdbc:sqlserver://DESKTOP-JE39UHF\\SQLEXPRESS:1433;databaseName=Veterinaria";
    private String USER = "sa";
    private String PASS= "123456";
    
    /**
     *
     * @return
     */
    public ArrayList<Especie> obtenerEspecies()
    {
        ArrayList<Especie> lista = new ArrayList<>();
        Connection con = null;
        
        try
        {
            con = DriverManager.getConnection(CONN, USER, PASS);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Especies");
            
            while (rs.next()) 
            {
                int idEspecie = rs.getInt(1);
                String denominacion = rs.getString(2);
                
                Especie e = new Especie(idEspecie, denominacion);
                lista.add(e);                       
            }
            
            rs.close();
            st.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (con !=null && !con.isClosed()) 
                {
                    con.close();
                }
            }
            catch(Exception exc)
            {
                exc.printStackTrace();
            }
        }
        return lista;        
    }
        
    public Especie obtenerEspecie(int idEspecie)
    {
        Especie resultado = null;
        Connection con = null;
        try
        {
            con = DriverManager.getConnection(CONN, USER, PASS);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Especies WHERE id=?");
            
            ps.setInt(1, idEspecie);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) 
            {
                int idE = rs.getInt(1);
                String nombre = rs.getString(2);
                
                resultado = new Especie(idE, nombre);
            }
            
            rs.close();
            ps.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (con != null && !con.isClosed()) 
                {
                    con.close();
                }
            }
            catch(Exception exc)
            {
                exc.printStackTrace();
            }
        }
        
        return resultado;        
    }
    
    public Cliente obtenerCliente(int idCliente)
    {
        Cliente resultado = null;
        Connection con = null;
        try
        {
            con = DriverManager.getConnection(CONN, USER, PASS);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Clientes WHERE id=?");
            
            ps.setInt(1, idCliente);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) 
            {
                int idC = rs.getInt(1);
                String nombre = rs.getString(2);
                String telefono = rs.getString(3);
                
                resultado = new Cliente(idC, nombre, telefono);
            }
            
            rs.close();
            ps.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (con != null && !con.isClosed()) 
                {
                    con.close();
                }
            }
            catch(Exception exc)
            {
                exc.printStackTrace();
            }
        }
        
        return resultado;        
    }
    
    public ArrayList<Mascota> obtenerMascotas()
    {
        ArrayList<Mascota> lista = new ArrayList<>();
        Connection con = null;
        
        try
        {
            con = DriverManager.getConnection(CONN, USER, PASS);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Mascotas");
            
            while (rs.next()) 
            {
                int idMascota = rs.getInt(1);
                String nombre = rs.getString(2);
                int idCliente = rs.getInt(3);
                int idEspecie = rs.getInt(4);
                int nacimiento = rs.getInt(5);
                
                Cliente cliente = obtenerCliente(idCliente);
                Especie especie = obtenerEspecie(idEspecie);
                
                Mascota m = new Mascota(idMascota, nombre, cliente , especie, nacimiento);
                lista.add(m);                       
            }
            
            rs.close();
            st.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (con !=null && !con.isClosed()) 
                {
                    con.close();
                }
            }
            catch(Exception exc)
            {
                exc.printStackTrace();
            }
        }
        return lista;        
    }
    
    public ArrayList<Cliente> obtenerClientes()
    {
        ArrayList<Cliente> lista = new ArrayList<>();
        Connection con = null;
        
        try
        {
            con = DriverManager.getConnection(CONN, USER, PASS);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Clientes");
            
            while (rs.next()) 
            {
                int idCliente = rs.getInt(1);
                String nombre = rs.getString(2);
                String telefono = rs.getString(3);
                
                Cliente c = new Cliente(idCliente, nombre, telefono);
                lista.add(c);                       
            }
            
            rs.close();
            st.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (con !=null && !con.isClosed()) 
                {
                    con.close();
                }
            }
            catch(Exception exc)
            {
                exc.printStackTrace();
            }
        }
        return lista;        
    }
    
    public void agregarMascota(Mascota m)
    {
        Connection conn = null;
        try 
        {
            conn = DriverManager.getConnection(CONN,USER,PASS);            
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Mascotas VALUES (?,?,?,?)");
            ps.setString(1,m.getNombre());
            ps.setInt(2, m.getCliente().getIdCliente());
            ps.setInt(3, m.getEspecie().getIdEspecie());
            ps.setInt(4, m.getNacimiento());
            
            ps.executeUpdate();
            ps.close();                    
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
        finally
        {
            try
            {
                if (conn != null && !conn.isClosed()) 
                {
                    conn.close();
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    
    
}
