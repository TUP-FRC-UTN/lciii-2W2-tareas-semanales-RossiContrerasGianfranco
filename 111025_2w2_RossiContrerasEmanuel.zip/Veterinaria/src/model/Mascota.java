package model;

public class Mascota 
{
    private int idMascota;
    private String nombre;
    private Cliente cliente;
    private Especie especie;
    private int nacimiento;

    public int getIdMascota() {
        return idMascota;
    }

    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    

    public Especie getEspecie() {
        return especie;
    }

    public void setEspecie(Especie especie) {
        this.especie = especie;
    }

    public int getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(int nacimiento) {
        this.nacimiento = nacimiento;
    }

    public Mascota(int idMascota, String nombre, Cliente cliente, Especie especie, int nacimiento) {
        this.idMascota = idMascota;
        this.nombre = nombre;
        this.cliente = cliente;
        this.especie = especie;
        this.nacimiento = nacimiento;
    }

    public Mascota(String nombre, Cliente cliente, Especie especie, int nacimiento) {
        this.idMascota = -1;
        this.nombre = nombre;
        this.cliente = cliente;
        this.especie = especie;
        this.nacimiento = nacimiento;
    }

    public Mascota(int idMascota, String nombre, Cliente cliente) {
        this.idMascota = idMascota;
        this.nombre = nombre;
        this.cliente = cliente;
    }

    
    
    
}
