package model;

public class Especie 
{
    private int idEspecie;
    private String denominacion;

    public int getIdEspecie() {
        return idEspecie;
    }

    public void setIdEspecie(int idEspecie) {
        this.idEspecie = idEspecie;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    public Especie(int idEspecie, String denominacion) {
        this.idEspecie = idEspecie;
        this.denominacion = denominacion;
    }

    @Override
    public String toString() {
        return denominacion;
    }
    
    
}
